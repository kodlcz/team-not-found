Prostredi
---------

Windows 64bit

Jazyk a knihovna
---------
Python

Autori
------

Nazev tymu
- xkadlea00 Adam Kadlec
- xtihelw00 William Denis Tihelka
- xvacekj00 Jan Vacek 

instalace a odinstalace
-------
program se nainstaluje pomocí přiloženého instalátoru v adresáři install/nej kalkulačka install
odinstalaci lze provést buď v aplikacích windows nebo v složce ve do které byl program uložen

co to je za projekt?
-------
jedná se grafickou kalkulačku s vlastní knihovnou a profilerem který vytváří složku s tím jak daný výpočet směrodatné odchylky probíhalo.

Licence
-------

Tento program je poskytovan v ramci lincence GNU General Public License v3.0
