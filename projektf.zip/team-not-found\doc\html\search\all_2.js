var searchData=
[
  ['backspace_0',['backspace',['../classmockup_1_1_calculator.html#aaa0e44c685f69ca59a12044f0cbd221b',1,'mockup::Calculator']]],
  ['buttons_5fframe_1',['buttons_frame',['../classmockup_1_1_calculator.html#ac0fec653025844c146d67137d644b75e',1,'mockup::Calculator']]]
];
