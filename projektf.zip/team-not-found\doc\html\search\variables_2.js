var searchData=
[
  ['current_5fexpression_0',['current_expression',['../classmockup_1_1_calculator.html#aa5f092a1e9096e85c0a9ef4fe8fdb070',1,'mockup::Calculator']]]
];
