var searchData=
[
  ['backspace_0',['backspace',['../classmockup_1_1_calculator.html#aaa0e44c685f69ca59a12044f0cbd221b',1,'mockup::Calculator']]]
];
