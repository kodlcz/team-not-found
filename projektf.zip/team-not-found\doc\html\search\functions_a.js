var searchData=
[
  ['run_5fprofiled_5fcalculations_0',['run_profiled_calculations',['../namespacestddev.html#a92380d047a94d2b2b76a049baf789bd2',1,'stddev']]]
];
