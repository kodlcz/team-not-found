var searchData=
[
  ['display_5fframe_0',['display_frame',['../classmockup_1_1_calculator.html#a3da92e8366dc2b3bfec49787a57133ef',1,'mockup::Calculator']]]
];
