var searchData=
[
  ['stddev_0',['stddev',['../namespacestddev.html',1,'']]]
];
