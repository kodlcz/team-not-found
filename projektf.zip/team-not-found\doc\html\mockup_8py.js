var mockup_8py =
[
    [ "mockup.Calculator", "classmockup_1_1_calculator.html", "classmockup_1_1_calculator" ],
    [ "mockup.app", "namespacemockup.html#a675c4a0d463021086b64fea1418a914f", null ],
    [ "mockup.root", "namespacemockup.html#ae68ee5cc48fc3222d21c533caa754b34", null ]
];