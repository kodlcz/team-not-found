var searchData=
[
  ['buttons_5fframe_0',['buttons_frame',['../classmockup_1_1_calculator.html#ac0fec653025844c146d67137d644b75e',1,'mockup::Calculator']]]
];
