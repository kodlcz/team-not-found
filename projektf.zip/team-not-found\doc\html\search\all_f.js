var searchData=
[
  ['update_5fdisplay_0',['update_display',['../classmockup_1_1_calculator.html#ac4f809d1e5109c2695a9b17cacfd40f8',1,'mockup::Calculator']]]
];
