var searchData=
[
  ['_5f_5finit_5f_5f_0',['__init__',['../classmockup_1_1_calculator.html#ad551c87c17fe5c8d81faa1d3a523209d',1,'mockup::Calculator']]]
];
