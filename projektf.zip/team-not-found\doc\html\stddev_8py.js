var stddev_8py =
[
    [ "stddev.calculate_stddev", "namespacestddev.html#a8b928be27091da0993414b9741dadf45", null ],
    [ "stddev.run_profiled_calculations", "namespacestddev.html#a92380d047a94d2b2b76a049baf789bd2", null ],
    [ "stddev.INPUT_SIZE", "namespacestddev.html#a3ca4aa5560f36c325a455fa7b0c7c52e", null ]
];