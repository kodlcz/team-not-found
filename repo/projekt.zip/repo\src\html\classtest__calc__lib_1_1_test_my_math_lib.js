var classtest__calc__lib_1_1_test_my_math_lib =
[
    [ "test_abs", "classtest__calc__lib_1_1_test_my_math_lib.html#a5779a840f0a16e0a5b8e780bfe7b7eda", null ],
    [ "test_add", "classtest__calc__lib_1_1_test_my_math_lib.html#a8c10b23da3487ce75fa61ac2c7543900", null ],
    [ "test_div", "classtest__calc__lib_1_1_test_my_math_lib.html#a1cbe3250d6e5a829b10e0c695cae5a21", null ],
    [ "test_div_zero", "classtest__calc__lib_1_1_test_my_math_lib.html#a2ecd6ed03297f89a6d41b7f2e11120b2", null ],
    [ "test_expon", "classtest__calc__lib_1_1_test_my_math_lib.html#a5c8cba20f97d33dec1129a0d067b08af", null ],
    [ "test_factorial", "classtest__calc__lib_1_1_test_my_math_lib.html#aec24e0f8ded37d3c2712ce4507f7c275", null ],
    [ "test_factorial_value_err", "classtest__calc__lib_1_1_test_my_math_lib.html#a09aff284c0e93ae1a8dc2436aabf610c", null ],
    [ "test_fib", "classtest__calc__lib_1_1_test_my_math_lib.html#a7d322c5d63a89051e2e89fadaa49f2cb", null ],
    [ "test_mul", "classtest__calc__lib_1_1_test_my_math_lib.html#a4ec3ad1d5b392b24228fccab4b228e2d", null ],
    [ "test_sqr", "classtest__calc__lib_1_1_test_my_math_lib.html#a11f8feb4f2267e4af37477465e244108", null ],
    [ "test_sub", "classtest__calc__lib_1_1_test_my_math_lib.html#a2f65504a24647d9b062cdb85d5195f8a", null ],
    [ "test_value", "classtest__calc__lib_1_1_test_my_math_lib.html#aaf6edc0f9fbdd5e453dece42af2a5919", null ]
];