var searchData=
[
  ['show_5fhelp_0',['show_help',['../namespacemockup.html#a86ec8e0c2ee1253d099cd489c7e5de31',1,'mockup']]],
  ['sqr_1',['sqr',['../namespacecalc__lib.html#a0e4a3922d65b4a1832c56d2cc55c5482',1,'calc_lib']]],
  ['stddev_2',['stddev',['../namespacestddev.html',1,'']]],
  ['stddev_2epy_3',['stddev.py',['../stddev_8py.html',1,'']]],
  ['sub_4',['sub',['../namespacecalc__lib.html#a14243826848575297bc35c8fbf957d9d',1,'calc_lib']]]
];
