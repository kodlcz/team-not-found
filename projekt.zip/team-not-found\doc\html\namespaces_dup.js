var namespaces_dup =
[
    [ "calc_lib", "namespacecalc__lib.html", [
      [ "absolute", "namespacecalc__lib.html#a7453442d8b95cdf8cd0252a4782c1ca7", null ],
      [ "add", "namespacecalc__lib.html#a6457ae41696082f1cb72538b23966b35", null ],
      [ "div", "namespacecalc__lib.html#a727a4270be6e178a633d6242393c6220", null ],
      [ "expon", "namespacecalc__lib.html#a5216dec23ea9109e55cad494402ab599", null ],
      [ "factorial", "namespacecalc__lib.html#a3faa8a9bbe33e1d704200fd84b922608", null ],
      [ "fib", "namespacecalc__lib.html#a4a43a0c6e913799ca3b894dfff0f4050", null ],
      [ "mul", "namespacecalc__lib.html#a7db5e5f1216900c05b54329e611f75d4", null ],
      [ "sqr", "namespacecalc__lib.html#a0e4a3922d65b4a1832c56d2cc55c5482", null ],
      [ "sub", "namespacecalc__lib.html#a14243826848575297bc35c8fbf957d9d", null ]
    ] ],
    [ "mockup", "namespacemockup.html", "namespacemockup" ],
    [ "stddev", "namespacestddev.html", [
      [ "calculate_stddev", "namespacestddev.html#a8b928be27091da0993414b9741dadf45", null ],
      [ "run_profiled_calculations", "namespacestddev.html#a92380d047a94d2b2b76a049baf789bd2", null ],
      [ "INPUT_SIZE", "namespacestddev.html#a3ca4aa5560f36c325a455fa7b0c7c52e", null ]
    ] ],
    [ "test_calc_lib", "namespacetest__calc__lib.html", "namespacetest__calc__lib" ]
];