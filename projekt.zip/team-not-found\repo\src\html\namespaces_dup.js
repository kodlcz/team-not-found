var namespaces_dup =
[
    [ "calc_lib", "namespacecalc__lib.html", [
      [ "absolute", "namespacecalc__lib.html#a7453442d8b95cdf8cd0252a4782c1ca7", null ],
      [ "add", "namespacecalc__lib.html#a6457ae41696082f1cb72538b23966b35", null ],
      [ "div", "namespacecalc__lib.html#a727a4270be6e178a633d6242393c6220", null ],
      [ "expon", "namespacecalc__lib.html#a5216dec23ea9109e55cad494402ab599", null ],
      [ "factorial", "namespacecalc__lib.html#a3faa8a9bbe33e1d704200fd84b922608", null ],
      [ "fib", "namespacecalc__lib.html#a4a43a0c6e913799ca3b894dfff0f4050", null ],
      [ "mul", "namespacecalc__lib.html#a7db5e5f1216900c05b54329e611f75d4", null ],
      [ "sqr", "namespacecalc__lib.html#a0e4a3922d65b4a1832c56d2cc55c5482", null ],
      [ "sub", "namespacecalc__lib.html#a14243826848575297bc35c8fbf957d9d", null ]
    ] ],
    [ "mockup", "namespacemockup.html", [
      [ "backspace", "namespacemockup.html#a1a020f633bd89cc77de549a5443ce00a", null ],
      [ "calculate", "namespacemockup.html#adde0aeb786372da61eee149a564b80de", null ],
      [ "call_factorial", "namespacemockup.html#a18bb4ba2c5775bd861c07fa0a7dd78da", null ],
      [ "call_fibonacci", "namespacemockup.html#a4cf3622558dbcc4680b4834be1f10c80", null ],
      [ "call_power", "namespacemockup.html#ac7aad6782447ce2d8beffdbe00e10c20", null ],
      [ "call_root", "namespacemockup.html#ab4beaf401f83b8dd507edf684c5b8e5a", null ],
      [ "clear", "namespacemockup.html#a6b3b6150ac64bf7e5e68290b3987e3fa", null ],
      [ "insert_char", "namespacemockup.html#a8096a5ab6a4e6899cba185feb602a84b", null ],
      [ "key_handler", "namespacemockup.html#a76fe4dd5e67f868c7ecf0001395da297", null ],
      [ "show_help", "namespacemockup.html#a86ec8e0c2ee1253d099cd489c7e5de31", null ],
      [ "btn", "namespacemockup.html#a0eb8e1098459af2517a75597398337b4", null ],
      [ "buttons", "namespacemockup.html#a577936ae9928a965f11aaba83673cb84", null ],
      [ "col", "namespacemockup.html#a0e1a6e64f34cb88d77b55fb4630ebc47", null ],
      [ "column", "namespacemockup.html#a929cf1aaa1fe6930836cee1f30f99fc7", null ],
      [ "columnspan", "namespacemockup.html#a5adb47451cbbef7a18db85e469363145", null ],
      [ "entry", "namespacemockup.html#ab3faf13759cb34f796cc92d1d62e68cf", null ],
      [ "padx", "namespacemockup.html#a033e059a8e12a4822aae870e8f468581", null ],
      [ "pady", "namespacemockup.html#a8ceb793b5f08cb3f2a7867eba3fa4938", null ],
      [ "root", "namespacemockup.html#ae68ee5cc48fc3222d21c533caa754b34", null ],
      [ "row", "namespacemockup.html#a30fdb1dad8d406d2667de8fd433a7493", null ]
    ] ],
    [ "stddev", "namespacestddev.html", [
      [ "calculate_stddev", "namespacestddev.html#a8b928be27091da0993414b9741dadf45", null ],
      [ "run_profiled_calculations", "namespacestddev.html#a92380d047a94d2b2b76a049baf789bd2", null ],
      [ "INPUT_SIZE", "namespacestddev.html#a3ca4aa5560f36c325a455fa7b0c7c52e", null ]
    ] ],
    [ "test_calc_lib", "namespacetest__calc__lib.html", "namespacetest__calc__lib" ]
];