var mockup_8py =
[
    [ "mockup.backspace", "namespacemockup.html#a1a020f633bd89cc77de549a5443ce00a", null ],
    [ "mockup.calculate", "namespacemockup.html#adde0aeb786372da61eee149a564b80de", null ],
    [ "mockup.call_factorial", "namespacemockup.html#a18bb4ba2c5775bd861c07fa0a7dd78da", null ],
    [ "mockup.call_fibonacci", "namespacemockup.html#a4cf3622558dbcc4680b4834be1f10c80", null ],
    [ "mockup.call_power", "namespacemockup.html#ac7aad6782447ce2d8beffdbe00e10c20", null ],
    [ "mockup.call_root", "namespacemockup.html#ab4beaf401f83b8dd507edf684c5b8e5a", null ],
    [ "mockup.clear", "namespacemockup.html#a6b3b6150ac64bf7e5e68290b3987e3fa", null ],
    [ "mockup.insert_char", "namespacemockup.html#a8096a5ab6a4e6899cba185feb602a84b", null ],
    [ "mockup.key_handler", "namespacemockup.html#a76fe4dd5e67f868c7ecf0001395da297", null ],
    [ "mockup.show_help", "namespacemockup.html#a86ec8e0c2ee1253d099cd489c7e5de31", null ],
    [ "mockup.btn", "namespacemockup.html#a0eb8e1098459af2517a75597398337b4", null ],
    [ "mockup.buttons", "namespacemockup.html#a577936ae9928a965f11aaba83673cb84", null ],
    [ "mockup.col", "namespacemockup.html#a0e1a6e64f34cb88d77b55fb4630ebc47", null ],
    [ "mockup.column", "namespacemockup.html#a929cf1aaa1fe6930836cee1f30f99fc7", null ],
    [ "mockup.columnspan", "namespacemockup.html#a5adb47451cbbef7a18db85e469363145", null ],
    [ "mockup.entry", "namespacemockup.html#ab3faf13759cb34f796cc92d1d62e68cf", null ],
    [ "mockup.padx", "namespacemockup.html#a033e059a8e12a4822aae870e8f468581", null ],
    [ "mockup.pady", "namespacemockup.html#a8ceb793b5f08cb3f2a7867eba3fa4938", null ],
    [ "mockup.root", "namespacemockup.html#ae68ee5cc48fc3222d21c533caa754b34", null ],
    [ "mockup.row", "namespacemockup.html#a30fdb1dad8d406d2667de8fd433a7493", null ]
];