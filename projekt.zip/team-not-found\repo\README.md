Prostredi
---------

Windows 64bit

Jazyk a knihovna
---------
Python
    tkinter

Autori
------

Nazev tymu
- xkadlea00 Adam Kadlec
- xtihelw00 William Denis Tihelka
- xvacekj00 Jan Vacek 

Licence
-------

Tento program je poskytovan v ramci lincence GNU General Public License v3.0
