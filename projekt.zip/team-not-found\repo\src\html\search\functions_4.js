var searchData=
[
  ['expon_0',['expon',['../namespacecalc__lib.html#a5216dec23ea9109e55cad494402ab599',1,'calc_lib']]]
];
