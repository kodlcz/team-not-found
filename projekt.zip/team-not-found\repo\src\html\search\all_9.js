var searchData=
[
  ['padx_0',['padx',['../namespacemockup.html#a033e059a8e12a4822aae870e8f468581',1,'mockup']]],
  ['pady_1',['pady',['../namespacemockup.html#a8ceb793b5f08cb3f2a7867eba3fa4938',1,'mockup']]]
];
