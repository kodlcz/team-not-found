var searchData=
[
  ['input_5fsize_0',['INPUT_SIZE',['../namespacestddev.html#a3ca4aa5560f36c325a455fa7b0c7c52e',1,'stddev']]]
];
