var searchData=
[
  ['stddev_2epy_0',['stddev.py',['../stddev_8py.html',1,'']]]
];
