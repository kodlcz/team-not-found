var files_dup =
[
    [ "calc_lib.py", "calc__lib_8py.html", "calc__lib_8py" ],
    [ "mockup.py", "mockup_8py.html", "mockup_8py" ],
    [ "profiling.py", "profiling_8py.html", "profiling_8py" ],
    [ "test_calc_lib.py", "test__calc__lib_8py.html", "test__calc__lib_8py" ]
];