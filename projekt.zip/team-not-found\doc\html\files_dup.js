var files_dup =
[
    [ "calc_lib.py", "calc__lib_8py.html", "calc__lib_8py" ],
    [ "mockup.py", "mockup_8py.html", "mockup_8py" ],
    [ "stddev.py", "stddev_8py.html", "stddev_8py" ],
    [ "test_calc_lib.py", "test__calc__lib_8py.html", "test__calc__lib_8py" ]
];